from django.db import models

# Create your models here.
class Member_class(models.Model) : 
    firstname = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255)
    phone=models.IntegerField(null=True, blank=True)
    joined_date=models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.firstname} {self.lastname}"


